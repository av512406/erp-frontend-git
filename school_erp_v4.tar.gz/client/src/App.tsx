import { useState, useEffect } from "react";
import { Switch, Route, useLocation, Redirect } from "wouter";

// ... imports remain the same

interface ProtectedRouteProps {
  allowedRoles: ('admin' | 'teacher')[];
  userRole: 'admin' | 'teacher';
  children: React.ReactNode;
}

function ProtectedRoute({ allowedRoles, userRole, children }: ProtectedRouteProps) {
  if (!allowedRoles.includes(userRole)) {
    return <Redirect to="/" />;
  }
  return <>{children}</>;
}

function Router({ user }: { user: User }) {
  // ... existing state and effects ...

  // ... existing handlers ...

  return (
    <Switch>
      <Route path="/">
        <Dashboard stats={stats} userRole={user.role} />
      </Route>
      <Route path="/students">
        <ProtectedRoute allowedRoles={['admin']} userRole={user.role}>
          <StudentsPage
            students={students}
            onAddStudent={handleAddStudent}
            onEditStudent={handleEditStudent}
            onDeleteStudent={handleDeleteStudent}
            onMarkWithdrawn={handleMarkWithdrawn}
          />
        </ProtectedRoute>
      </Route>
      <Route path="/students-withdrawn">
        <ProtectedRoute allowedRoles={['admin']} userRole={user.role}>
          <WithdrawnStudentsPage students={withdrawnStudents} onRestore={async (admissionNumber) => {
            try {
              const res = await fetch(`/api/students/${encodeURIComponent(admissionNumber)}/restore`, { method: 'PUT' });
              if (!res.ok) {
                const msg = await (async () => { try { const j = await res.json(); return j?.message; } catch { return ''; } })();
                throw new Error(msg || 'Failed to restore');
              }
              const restored = await res.json();
              setWithdrawnStudents(prev => prev.filter(s => s.admissionNumber !== admissionNumber));
              setStudents(prev => [...prev, restored]);
            } catch (e: any) {
              alert(e?.message || 'Restore failed');
            }
          }} />
        </ProtectedRoute>
      </Route>
      <Route path="/students-left">
        <ProtectedRoute allowedRoles={['admin']} userRole={user.role}>
          <WithdrawnStudentsPage students={withdrawnStudents} onRestore={async (admissionNumber) => {
            try {
              const res = await fetch(`/api/students/${encodeURIComponent(admissionNumber)}/restore`, { method: 'PUT' });
              if (!res.ok) {
                const msg = await (async () => { try { const j = await res.json(); return j?.message; } catch { return ''; } })();
                throw new Error(msg || 'Failed to restore');
              }
              const restored = await res.json();
              setWithdrawnStudents(prev => prev.filter(s => s.admissionNumber !== admissionNumber));
              setStudents(prev => [...prev, restored]);
            } catch (e: any) {
              alert(e?.message || 'Restore failed');
            }
          }} />
        </ProtectedRoute>
      </Route>
      <Route path="/fees">
        <ProtectedRoute allowedRoles={['admin']} userRole={user.role}>
          <FeesPage
            students={students}
            transactions={transactions}
            onAddTransaction={handleAddTransaction}
          />
        </ProtectedRoute>
      </Route>
      <Route path="/data-tools">
        <ProtectedRoute allowedRoles={['admin']} userRole={user.role}>
          <DataToolsPage
            students={students}
            onImportStudents={handleImportStudents}
            onUpsertStudents={handleUpsertStudents}
            onImportGrades={handleImportGrades}
            onImportTransactions={handleImportTransactions}
          />
        </ProtectedRoute>
      </Route>
      <Route path="/subjects">
        <ProtectedRoute allowedRoles={['admin']} userRole={user.role}>
          <SubjectsPage students={students} />
        </ProtectedRoute>
      </Route>
      <Route path="/grades">
        {/* Grades accessible to both */}
        <GradesPage
          students={students}
          grades={grades}
          onSaveGrades={handleSaveGrades}
          saving={savingGrades}
        />
      </Route>
      <Route path="/reports">
        <ProtectedRoute allowedRoles={['admin']} userRole={user.role}>
          <ReportsPage students={students} grades={grades} />
        </ProtectedRoute>
      </Route>
      <Route path="/admin-settings">
        <ProtectedRoute allowedRoles={['admin']} userRole={user.role}>
          <AdminSettingsPage />
        </ProtectedRoute>
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [user, setUser] = useState<User | null>(null);

  const handleLogin = (email: string, password: string) => {
    if (email === 'admin@school.edu' && password === 'admin123') {
      setUser({ email, role: 'admin' });
    } else if (email === 'teacher@school.edu' && password === 'teacher123') {
      setUser({ email, role: 'teacher' });
    }
  };

  const handleLogout = () => {
    setUser(null);
  };

  if (!user) {
    return (
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <LoginPage onLogin={handleLogin} />
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen bg-background">
          <Navigation userRole={user.role} userEmail={user.email} onLogout={handleLogout} />
          <Router user={user} />
        </div>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
