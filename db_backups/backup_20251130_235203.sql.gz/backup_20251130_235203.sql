--
-- PostgreSQL database dump
--

\restrict I9Dr4bfE9HO6iYxqhFu9u3lUishJs5s9wJXPvc1L99XSIDPvB8pryabIJnTY6HJ

-- Dumped from database version 16.11 (Debian 16.11-1.pgdg13+1)
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: school_erp
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      BEGIN
        NEW.updated_at = now();
        RETURN NEW;
      END;
      $$;


ALTER FUNCTION public.set_updated_at() OWNER TO school_erp;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: class_subjects; Type: TABLE; Schema: public; Owner: school_erp
--

CREATE TABLE public.class_subjects (
    id text NOT NULL,
    grade text NOT NULL,
    subject_id text NOT NULL,
    max_marks numeric(6,2),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    school_id text NOT NULL
);


ALTER TABLE public.class_subjects OWNER TO school_erp;

--
-- Name: fee_transactions; Type: TABLE; Schema: public; Owner: school_erp
--

CREATE TABLE public.fee_transactions (
    id text NOT NULL,
    student_id text NOT NULL,
    transaction_id text NOT NULL,
    amount numeric(10,2) NOT NULL,
    payment_date date NOT NULL,
    payment_mode text DEFAULT 'cash'::text NOT NULL,
    remarks text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    receipt_serial integer,
    school_id text NOT NULL,
    CONSTRAINT fee_amount_positive CHECK ((amount > (0)::numeric)),
    CONSTRAINT fee_payment_mode_allowed CHECK ((payment_mode = ANY (ARRAY['cash'::text, 'card'::text, 'upi'::text, 'cheque'::text, 'bank-transfer'::text, 'other'::text])))
);


ALTER TABLE public.fee_transactions OWNER TO school_erp;

--
-- Name: grades; Type: TABLE; Schema: public; Owner: school_erp
--

CREATE TABLE public.grades (
    id text NOT NULL,
    student_id text NOT NULL,
    subject text NOT NULL,
    marks numeric(5,2) NOT NULL,
    term text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    school_id text NOT NULL
);


ALTER TABLE public.grades OWNER TO school_erp;

--
-- Name: receipt_serial_seq; Type: SEQUENCE; Schema: public; Owner: school_erp
--

CREATE SEQUENCE public.receipt_serial_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.receipt_serial_seq OWNER TO school_erp;

--
-- Name: receipt_serial_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: school_erp
--

ALTER SEQUENCE public.receipt_serial_seq OWNED BY public.fee_transactions.receipt_serial;


--
-- Name: schools; Type: TABLE; Schema: public; Owner: school_erp
--

CREATE TABLE public.schools (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    address text,
    phone text,
    logo_url text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.schools OWNER TO school_erp;

--
-- Name: session; Type: TABLE; Schema: public; Owner: school_erp
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.session OWNER TO school_erp;

--
-- Name: students; Type: TABLE; Schema: public; Owner: school_erp
--

CREATE TABLE public.students (
    id text NOT NULL,
    admission_number text NOT NULL,
    name text NOT NULL,
    date_of_birth date NOT NULL,
    admission_date date NOT NULL,
    aadhar_number text,
    pen_number text,
    aapar_id text,
    mobile_number text,
    address text,
    grade text,
    section text,
    father_name text,
    mother_name text,
    yearly_fee_amount numeric(10,2) NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    left_date date,
    leaving_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    category text DEFAULT 'GEN'::text,
    school_id text NOT NULL,
    gender text
);


ALTER TABLE public.students OWNER TO school_erp;

--
-- Name: subjects; Type: TABLE; Schema: public; Owner: school_erp
--

CREATE TABLE public.subjects (
    id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    school_id text NOT NULL
);


ALTER TABLE public.subjects OWNER TO school_erp;

--
-- Name: users; Type: TABLE; Schema: public; Owner: school_erp
--

CREATE TABLE public.users (
    id text NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    role text DEFAULT 'teacher'::text NOT NULL,
    name text DEFAULT 'User'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    school_id text
);


ALTER TABLE public.users OWNER TO school_erp;

--
-- Name: fee_transactions receipt_serial; Type: DEFAULT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.fee_transactions ALTER COLUMN receipt_serial SET DEFAULT nextval('public.receipt_serial_seq'::regclass);


--
-- Data for Name: class_subjects; Type: TABLE DATA; Schema: public; Owner: school_erp
--

COPY public.class_subjects (id, grade, subject_id, max_marks, created_at, updated_at, school_id) FROM stdin;
\.


--
-- Data for Name: fee_transactions; Type: TABLE DATA; Schema: public; Owner: school_erp
--

COPY public.fee_transactions (id, student_id, transaction_id, amount, payment_date, payment_mode, remarks, created_at, updated_at, receipt_serial, school_id) FROM stdin;
\.


--
-- Data for Name: grades; Type: TABLE DATA; Schema: public; Owner: school_erp
--

COPY public.grades (id, student_id, subject, marks, term, created_at, updated_at, school_id) FROM stdin;
\.


--
-- Data for Name: schools; Type: TABLE DATA; Schema: public; Owner: school_erp
--

COPY public.schools (id, name, slug, address, phone, logo_url, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: school_erp
--

COPY public.session (sid, sess, expire) FROM stdin;
et_8y-7BcV6QISXYZFSMo0PKTErCnLLT	{"cookie":{"originalMaxAge":2592000000,"expires":"2025-12-30T13:34:25.171Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":"93c38348-b5aa-46b3-96e2-d223452828c2","username":"admin@sds.com.com","role":"admin","name":"School Admin","schoolId":"72f4b603-19a6-48cb-a9f7-ed957d385694"}}	2025-12-30 19:04:26
NabKIB84S0QTSeUuuS5x7Q_AHwg4Njn8	{"cookie":{"originalMaxAge":2592000000,"expires":"2025-12-30T23:46:06.903Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":"super-admin-id","username":"av512406@school.com","role":"superadmin","name":"Super Admin","schoolId":null}}	2025-12-31 05:16:09
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: school_erp
--

COPY public.students (id, admission_number, name, date_of_birth, admission_date, aadhar_number, pen_number, aapar_id, mobile_number, address, grade, section, father_name, mother_name, yearly_fee_amount, status, left_date, leaving_reason, created_at, updated_at, category, school_id, gender) FROM stdin;
\.


--
-- Data for Name: subjects; Type: TABLE DATA; Schema: public; Owner: school_erp
--

COPY public.subjects (id, code, name, created_at, updated_at, school_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: school_erp
--

COPY public.users (id, username, password, role, name, created_at, updated_at, school_id) FROM stdin;
super-admin-id	av512406@school.com	Anand@8520#	superadmin	Super Admin	2025-12-01 05:16:08.765569+05:30	2025-12-01 05:16:08.765569+05:30	\N
\.


--
-- Name: receipt_serial_seq; Type: SEQUENCE SET; Schema: public; Owner: school_erp
--

SELECT pg_catalog.setval('public.receipt_serial_seq', 1, false);


--
-- Name: class_subjects class_subjects_grade_subject_id_key; Type: CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.class_subjects
    ADD CONSTRAINT class_subjects_grade_subject_id_key UNIQUE (grade, subject_id);


--
-- Name: class_subjects class_subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.class_subjects
    ADD CONSTRAINT class_subjects_pkey PRIMARY KEY (id);


--
-- Name: fee_transactions fee_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.fee_transactions
    ADD CONSTRAINT fee_transactions_pkey PRIMARY KEY (id);


--
-- Name: fee_transactions fee_transactions_transaction_id_key; Type: CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.fee_transactions
    ADD CONSTRAINT fee_transactions_transaction_id_key UNIQUE (transaction_id);


--
-- Name: grades grades_pkey; Type: CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_pkey PRIMARY KEY (id);


--
-- Name: schools schools_pkey; Type: CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.schools
    ADD CONSTRAINT schools_pkey PRIMARY KEY (id);


--
-- Name: schools schools_slug_key; Type: CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.schools
    ADD CONSTRAINT schools_slug_key UNIQUE (slug);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: students students_admission_number_key; Type: CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_admission_number_key UNIQUE (admission_number);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: subjects subjects_code_key; Type: CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_code_key UNIQUE (code);


--
-- Name: subjects subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_pkey PRIMARY KEY (id);


--
-- Name: grades uniq_grade_student_subject_term; Type: CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT uniq_grade_student_subject_term UNIQUE (student_id, subject, term);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: school_erp
--

CREATE INDEX "IDX_session_expire" ON public.session USING btree (expire);


--
-- Name: idx_fee_transactions_student_date; Type: INDEX; Schema: public; Owner: school_erp
--

CREATE INDEX idx_fee_transactions_student_date ON public.fee_transactions USING btree (student_id, payment_date);


--
-- Name: idx_fees_school_id; Type: INDEX; Schema: public; Owner: school_erp
--

CREATE INDEX idx_fees_school_id ON public.fee_transactions USING btree (school_id);


--
-- Name: idx_grades_student_term; Type: INDEX; Schema: public; Owner: school_erp
--

CREATE INDEX idx_grades_student_term ON public.grades USING btree (student_id, term);


--
-- Name: idx_students_grade_section; Type: INDEX; Schema: public; Owner: school_erp
--

CREATE INDEX idx_students_grade_section ON public.students USING btree (grade, section);


--
-- Name: idx_students_name; Type: INDEX; Schema: public; Owner: school_erp
--

CREATE INDEX idx_students_name ON public.students USING btree (name);


--
-- Name: idx_students_school_id; Type: INDEX; Schema: public; Owner: school_erp
--

CREATE INDEX idx_students_school_id ON public.students USING btree (school_id);


--
-- Name: idx_users_school_id; Type: INDEX; Schema: public; Owner: school_erp
--

CREATE INDEX idx_users_school_id ON public.users USING btree (school_id);


--
-- Name: fee_transactions fee_transactions_set_updated_at; Type: TRIGGER; Schema: public; Owner: school_erp
--

CREATE TRIGGER fee_transactions_set_updated_at BEFORE UPDATE ON public.fee_transactions FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: grades grades_set_updated_at; Type: TRIGGER; Schema: public; Owner: school_erp
--

CREATE TRIGGER grades_set_updated_at BEFORE UPDATE ON public.grades FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: students students_set_updated_at; Type: TRIGGER; Schema: public; Owner: school_erp
--

CREATE TRIGGER students_set_updated_at BEFORE UPDATE ON public.students FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: class_subjects class_subjects_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.class_subjects
    ADD CONSTRAINT class_subjects_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: class_subjects class_subjects_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.class_subjects
    ADD CONSTRAINT class_subjects_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE CASCADE;


--
-- Name: fee_transactions fee_transactions_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.fee_transactions
    ADD CONSTRAINT fee_transactions_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: fee_transactions fee_transactions_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.fee_transactions
    ADD CONSTRAINT fee_transactions_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: grades grades_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: grades grades_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: students students_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: subjects subjects_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: users users_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: school_erp
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- PostgreSQL database dump complete
--

\unrestrict I9Dr4bfE9HO6iYxqhFu9u3lUishJs5s9wJXPvc1L99XSIDPvB8pryabIJnTY6HJ

